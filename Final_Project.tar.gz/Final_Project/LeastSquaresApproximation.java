/*
 * Welcome to my Least Squares Approximation program.
 * It will calculate the least squares polynomial of the specified degree for a given set of data-points.
 * 
 * USAGE (all on command line)::java LeastSquaresApproximation <filename> [<degree>]
 *      
 * 		filename is required.  Only takes in csv files.
 * 			EXAMPLE: for test.csv, "java LeastSquaresApproximation test".
 * 
 * 		degree is optional, defaults to 0.
 * 			if degree==0, does a full solve.
 * 			else if degree is >0 && <n(number of data points in csv).  Does a single solve for specified degree.
 * 
 * 			EXAMPLES: "java LeastSquaresApproximation test", "java LeastSquaresApproximation test 0", "java LeastSquaresApproximation test 3" 
 */
 
 
import java.util.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.Math.*;


public class LeastSquaresApproximation{
	public static Double one = new Double("1");


	public static void main(String[] args) {
		ArrayList<int[]> myListOfPairs = new ArrayList<int[]>();
		try{
			myListOfPairs = readFile("./"+args[0]+".csv");
		} catch(Exception e){
			e.printStackTrace();
		}
		
		if(args.length>1 && 0!=Integer.parseInt(args[1])){
			singleSolve(myListOfPairs, Integer.parseInt(args[1]));
		}
		else{
			fullSolve(myListOfPairs);
		}
		
		
		
		
		
		
		
		
		
		
		/*
		 * THE FOLLOWING COMMENTED OUT CODE WAS USED FOR TESTING PURPOSES.
		 * IT TESTED EVERY METHOD THAT I WROTE AS PART OF THIS FINAL ASSIGNMENT
		//Read in file.
		ArrayList<int[]> myListOfPairs = new ArrayList<int[]>();
		try{
			myListOfPairs = readFile("./5.csv");
		} catch(Exception e){
			e.printStackTrace();
		}
		//Create M Matrix
		ArrayList<ArrayList<Double>> myMMatrix = new ArrayList<ArrayList<Double>>();
		myMMatrix = toMMatrix(myListOfPairs,2);
		printMatrix(myMMatrix);
		System.out.println();
		//Create Y Matrix
		ArrayList<ArrayList<Double>> myYMatrix = new ArrayList<ArrayList<Double>>();
		myYMatrix = toYMatrix(myListOfPairs);
		System.out.println("Y-MATRIX");
		printMatrix(myYMatrix);
		System.out.println();
		//Transpose
		ArrayList<ArrayList<Double>> trans = new ArrayList<ArrayList<Double>>();
		trans = transpose(myMMatrix);
		System.out.println("TRANSPOSE");
		printMatrix(trans);
		System.out.println();
		//Multiply
		ArrayList<ArrayList<Double>> mult = new ArrayList<ArrayList<Double>>();
		mult = multiply(trans,myMMatrix);
		printMatrix(mult);
		System.out.println();
		//isValid
		System.out.println(isValid(myListOfPairs,3));
		System.out.println(isValid(myListOfPairs,7));
		System.out.println();
		//MINOR
		ArrayList<ArrayList<Double>> min = new ArrayList<ArrayList<Double>>();
		min = minor(mult,2,2);
		printMatrix(min);
		System.out.println();
		//Cofactor
		mult = multiply(trans,myMMatrix);
		System.out.println(cofactor(mult,0,0));
		mult = multiply(trans,myMMatrix);
		System.out.println(cofactor(mult,2,2));
		mult = multiply(trans,myMMatrix);
		System.out.println(cofactor(mult,1,1));
		mult = multiply(trans,myMMatrix);
		System.out.println(cofactor(mult,1,0));
		mult = multiply(trans,myMMatrix);
		System.out.println(cofactor(mult,1,2));
		//Determinant
		mult = multiply(trans,myMMatrix);
		System.out.println(determinant(mult));
		System.out.println(determinant(min));
		System.out.println();
		//Adjoint
		mult = multiply(trans,myMMatrix);
		printMatrix(adjoint(mult));
		System.out.println();
		//INVERSE
		mult = multiply(trans,myMMatrix);
		System.out.println("INVERSE");
		printMatrix(inverse(copy(mult)));
		System.out.println();
		//Single Solve && output solution.
		System.out.println("**SINGLE SOLVE**");
		singleSolve(myListOfPairs,2);
		System.out.println("**FULL SOLVE**");
		fullSolve(myListOfPairs);*/
    }
    
    public static ArrayList<int[]> readFile(String csvFile) throws IOException{
		ArrayList<int[]> output = new ArrayList<int[]>();
		try {
			FileReader fr = new FileReader(csvFile);
            BufferedReader reader = new BufferedReader(fr);
            String line = "";
            //System.out.println(reader.readLine());
            while ((line = reader.readLine()) != null) {
				int[] outLine = new int[2];
                String [] strArry = line.split(",");
                outLine[0] = Integer.parseInt(strArry[0]);
                outLine[1] = Integer.parseInt(strArry[1]);
                //System.out.println(outLine[0]);
                output.add(outLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return output;
	}
	
	public static ArrayList<ArrayList<Double>> toMMatrix (ArrayList<int[]> setList, int degree){
		ArrayList<ArrayList<Double>> outMatrix = new ArrayList<ArrayList<Double>>();
		for(int i=0; i<setList.size(); i++){
			ArrayList<Double> row = new ArrayList<Double>();
			row.add(one);
			for(int j=1; j<=degree; j++){
				row.add(Math.pow(setList.get(i)[0],j));
			}
			outMatrix.add(row);
		}
		return outMatrix;
	}
	
	public static ArrayList<ArrayList<Double>> toYMatrix(ArrayList<int[]> setList){
		ArrayList<ArrayList<Double>> yMatrix = new ArrayList<ArrayList<Double>>();
		for(int i=0; i<setList.size(); i++){
			ArrayList<Double> temp = new ArrayList<Double>();
			Double intermediary = new Double(setList.get(i)[1]);
			temp.add(intermediary);
			yMatrix.add(temp);
		}
		return yMatrix;
	}
	

	public static ArrayList<ArrayList<Double>> transpose(ArrayList<ArrayList<Double>> matrix){
		ArrayList<ArrayList<Double>> outMatrix = new ArrayList<ArrayList<Double>>();
		int m = matrix.size();
		int n = matrix.get(1).size();
		for(int column=0; column<n; column++){
			ArrayList<Double> rowToAdd = new ArrayList<Double>();
			for(int row=0; row<m; row++){
				rowToAdd.add(matrix.get(row).get(column));
			}
			outMatrix.add(rowToAdd);
		}
		return outMatrix;
	}
	
	public static ArrayList<ArrayList<Double>> multiply(ArrayList<ArrayList<Double>> matrix1, ArrayList<ArrayList<Double>> matrix2){
		int a = matrix1.size();
		int b1 = matrix1.get(1).size();
		int b2 = matrix2.size();
		int c = matrix2.get(1).size();
		
		ArrayList<ArrayList<Double>> outMatrix = new ArrayList<ArrayList<Double>>();
		
		if(b1!=b2){
			System.out.println("Matricies can't be multiplied");
			System.out.printf("a=%d,b1=%d,b2=%d,c=%d\n",a,b1,b2,c);
			return outMatrix;
		}
		
		for(int i=0; i<a; i++){
			ArrayList<Double> outRow = new ArrayList<Double>();
			for(int j=0; j<c; j++){
				Double outElement = new Double("0");
				for(int k=0; k<b1; k++){
					outElement += (matrix1.get(i).get(k)*matrix2.get(k).get(j));
				}
				outRow.add(outElement);
			}
			outMatrix.add(outRow);
		}
		return outMatrix;
	}
	
	public static ArrayList<ArrayList<Double>> inverse(ArrayList<ArrayList<Double>> matrix){
		ArrayList<ArrayList<Double>> outMatrix = new ArrayList<ArrayList<Double>>();
		Double determinant = determinant(copy(matrix));
		ArrayList<ArrayList<Double>> adj = adjoint(copy(matrix));
		for(int i=0; i<matrix.size(); i++){
			ArrayList<Double> outRow = new ArrayList<Double>();
			for(int j=0; j<matrix.get(1).size(); j++){
				outRow.add(adj.get(i).get(j)/determinant);
			}
			outMatrix.add(outRow);
		}
		return outMatrix;
	}
	
	public static void outputSolution(ArrayList<ArrayList<Double>> matrix){
		int degree = matrix.size()-1;
		String output = "" + matrix.get(0).get(0);
		output = output + " " + matrix.get(1).get(0) + "x";
		for(int i=2; i<=degree; i++){
			output = output + " " + matrix.get(i).get(0) + "x^"+i;
		}
		System.out.println(output);
	}
	
	public static void singleSolve(ArrayList<int[]> setList, int degree){
		ArrayList<ArrayList<Double>> M_matrix = toMMatrix(setList,degree);
		ArrayList<ArrayList<Double>> Y_matrix = toYMatrix(setList);
		ArrayList<ArrayList<Double>> trans = transpose(M_matrix);
		ArrayList<ArrayList<Double>> invrs = inverse(multiply(trans,M_matrix));
		ArrayList<ArrayList<Double>> solutionMatrix = multiply(invrs,multiply(trans,Y_matrix));
		outputSolution(solutionMatrix);
	}
	
	public static void fullSolve(ArrayList<int[]> setList){
		for(int i=1; i<setList.size(); i++){
			singleSolve(setList,i);
		}
	}
	
	public static boolean isValid(ArrayList<int[]> setList, int degree){
		if(degree<setList.size() && degree>0){
			return true;
		}
		return false;
	}
    
    public static ArrayList<ArrayList<Double>> minor(ArrayList<ArrayList<Double>> matrix, int row, int column){
		for(int i=0; i<matrix.size(); i++){
			matrix.get(i).remove(column);
		}
		matrix.remove(row);
		return matrix;
	}
	
	public static Double determinant(ArrayList<ArrayList<Double>> matrix){
		if(matrix.size() == 2){
			return matrix.get(0).get(0)*matrix.get(1).get(1)-matrix.get(0).get(1)*matrix.get(1).get(0);
		}
		else{
			Double det = new Double("0");
			ArrayList<ArrayList<Double>> sendMatrix = new ArrayList<ArrayList<Double>>();
			for(int i=0; i<matrix.size(); i++){
				sendMatrix = copy(matrix);
				det = det + matrix.get(0).get(i)*cofactor(sendMatrix,0,i);
			}
			return det;
		}
	}
    
    public static Double cofactor(ArrayList<ArrayList<Double>> matrix, int row, int column){
		int sign = (int)Math.pow((-1),row+column);
		ArrayList<ArrayList<Double>> min = minor(matrix,row,column);
		return sign*determinant(min);
	}
    
    public static ArrayList<ArrayList<Double>> adjoint(ArrayList<ArrayList<Double>> matrix){
		ArrayList<ArrayList<Double>> outMatrix = new ArrayList<ArrayList<Double>>();
		for(int i=0; i<matrix.size(); i++){
			ArrayList<Double> outRow = new ArrayList<Double>();
			for(int j=0; j<matrix.size(); j++){
				outRow.add(cofactor(copy(matrix),i,j));
			}
			outMatrix.add(outRow);			
		}
		return outMatrix;
	}
    
    public static void printMatrix(ArrayList<ArrayList<Double>> matrix){
		for(int i=0; i<matrix.size(); i++){
			System.out.print("[ ");
			for(int j=0; j<matrix.get(1).size(); j++){
				System.out.print(matrix.get(i).get(j) + " ");
			}
			System.out.printf("]\n");
		}
	}
    
    public static ArrayList<ArrayList<Double>> copy(ArrayList<ArrayList<Double>> matrix){
		ArrayList<ArrayList<Double>> output =  new ArrayList<ArrayList<Double>>();
		for(int i=0; i<matrix.size(); i++){
			ArrayList<Double> row = new ArrayList<Double>();
			for(int j=0; j<matrix.get(0).size(); j++){
				row.add(matrix.get(i).get(j));
			}
			output.add(row);
		}
		return output;
	}
    
    
    
    

}

