README::
	The following is an overview of the FINAL_PROJECT folder which contains the CSIS-3000 Final Project for Kevin Schwaar
	4/13/2018
	This project focused on Interpolation, Approximation, and Least Squares.
	
CONTENTS::
	5.csv
	100.csv
	1000.csv
	5.ods
	100.ods
	1000.ods
	LeastSquaresApproximation.java
	LeastSquaresApproximation.class
	LSTest.java
	LSTest.class
	presentation.odp
	
USAGE::
	Run LSTest in the cmd-line/terminal to test all methods of the program.  "java LSTest"
	
	Run LeastSquaresApproximation in cmd-line/terminal for a full usage of the program.
		This is only compatible with .csv files.
		See USAGE in in LeastSquaresApproximation.java for proper syntax.
